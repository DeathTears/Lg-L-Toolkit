Everything for lg l7 [P700]
